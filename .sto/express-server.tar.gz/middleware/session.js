const session = require('express-session');
const RedisStore = require('connect-redis').default;
const redis = require('redis');
const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');

// BEGIN Redis Client Configuration
const redisClient = redis.createClient({ url: process.env.REDIS_URL || 'redis://127.0.0.1:6380' });

redisClient.connect().catch(console.error); // Ensure Redis client connects properly

// Handle Redis connection events
redisClient.on('error', (err) => console.error('Redis connection error:', err));
redisClient.on('reconnecting', () => console.log('Reconnecting to Redis...'));
// END Redis Client Configuration

// BEGIN Log File Path Configuration
const logsDir = path.join(__dirname, '../logs');
const sessionLogFilePath = path.join(logsDir, 'redis-session.log');

// Ensure logs directory exists
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir); // Create logs directory if it doesn't exist
// END Log File Path Configuration

// BEGIN Session Timestamp Middleware
const sessionTimestampMiddleware = (req, res, next) => {
  if (req.session) {
    if (!req.session.createdAt) {
      // Set session creation time if not already set
      req.session.createdAt = moment().tz('Asia/Bangkok').format('YYYY-MM-DD HH:mm:ss z');
    }
    // Update last access time on every request
    req.session.lastAccess = moment().tz('Asia/Bangkok').format('YYYY-MM-DD HH:mm:ss z');
  }
  next();
};
// END Session Timestamp Middleware

// BEGIN Session Logger Middleware
const sessionLogger = (req, res, next) => {
  if (req.session) {
    const currentTime = moment().tz('Asia/Bangkok').format('YYYY-MM-DD HH:mm:ss z');
    const sessionID = req.sessionID;
    const requestIP = req.ip || 'Unknown';
    const userAgent = req.headers['user-agent'] || 'Unknown';
    const referer = req.headers['referer'] || 'None';
    const sessionCreation = req.session.createdAt || 'N/A';

    // Calculate session expiration based on maxAge
    const sessionExpires = req.session.cookie.expires
      ? moment(req.session.cookie.expires).tz('Asia/Bangkok').format('YYYY-MM-DD HH:mm:ss z')
      : 'N/A';
    
    const lastAccess = req.session.lastAccess || 'Unknown';

    const logMessage = `
  =============================================
  Session Activity:
    - Time: ${currentTime}
    - SessionID: ${sessionID}
    - Method: ${req.method}
    - URL: ${req.url}
    - IP: ${requestIP}
    - UserAgent: ${userAgent}
    - Referer: ${referer}
    - Created: ${sessionCreation}
    - Expires: ${sessionExpires}
    - Last Access: ${lastAccess}
  =============================================
`;
    // Log to console (optional)
    console.log(logMessage);

    // Append log entry to redis-session.log asynchronously with error handling
    fs.appendFile(sessionLogFilePath, logMessage, (err) => {
      if (err) {
        console.error('Error writing to session log file:', err);
      }
    });
  }
  next();
};
// END Session Logger Middleware

// BEGIN Express Session Configuration
const sessionManager = session({
  store: new RedisStore({ 
    client: redisClient,
    ttl: 3600  // Session TTL in seconds (1 hour)
  }),
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false, // Don't save session if unmodified
  saveUninitialized: false, // Don't create session until something is stored
  cookie: {
    secure: process.env.NODE_ENV === 'production', // Use secure cookies in production
    maxAge: 3600000,  // Session cookie expires after 1 hour
    httpOnly: true,   // Prevent client-side JavaScript access to cookies
    sameSite: 'lax'   // CSRF protection by allowing only same-site requests
  }
});
// END Express Session Configuration

// BEGIN Export Middleware Array
module.exports = [sessionManager, sessionTimestampMiddleware, sessionLogger];
// END Export Middleware Array
